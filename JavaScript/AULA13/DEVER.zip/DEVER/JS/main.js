let pessoa = [];

do {
    var set = window.prompt('Digite para: \n  (1)Cadastrar \n    (2)Consultar \n      (0)Sair');
    if (set == '0') break;

    function cadastrar() {
        pessoa.push([window.prompt("Nome:"), window.prompt("Peso:"), window.prompt("Altura:")]);
        return pessoa;
    }

    function consultar() {
        console.clear()
        for (let i = 0; i < pessoa.length; i++) {

            console.log('Nome: ' + pessoa[i][0] +
                '\n Peso: ' + pessoa[i][1] +
                '\n  Altura: ' + pessoa[i][2]);
        }
    }

    function menu() {
        switch (set) {
            case '1':
                cadastrar();
                break;

            case '2':
                consultar();
                break;

            case '0':
                break;

            default:
                window.alert("Opção invalida!")
                break;
        }
    }
    menu()

} while (set != '2')

do {
    if (set == '0') break;
    set = window.prompt('Digite para: \n  (1)Cadastrar \n    (2)Consultar \n      (0)Sair');
    if (set == '0') break;
    menu()
} while (set == '1' || set == '2')