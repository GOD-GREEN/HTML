 function limpar() {
     document.getElementById('bar').value = '';
}

function NumPressed(valor) {
    
    document.getElementById('bar').value += valor;
    
    
}
function Calcul() {
    var result = 0;
    result = document.getElementById('bar').value;
    
    document.getElementById('bar').value = '';

    document.getElementById('bar').value = eval(result);
}

